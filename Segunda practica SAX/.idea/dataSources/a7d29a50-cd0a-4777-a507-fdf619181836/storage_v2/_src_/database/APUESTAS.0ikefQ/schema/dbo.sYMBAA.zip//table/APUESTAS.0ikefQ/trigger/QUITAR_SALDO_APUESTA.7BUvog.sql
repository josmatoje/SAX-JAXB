--Cuando se realiza una apuesta. Este trigger actualiza el saldo del usuario tras realizar la apuesta.
CREATE TRIGGER QUITAR_SALDO_APUESTA
	ON APUESTAS
	AFTER INSERT
	AS
	BEGIN
		UPDATE USUARIOS
		SET SALDO = SALDO - (SELECT SUM(CANTIDAD) FROM inserted WHERE NOMBRE_USUARIO = NOMBRE)
		WHERE NOMBRE IN (SELECT NOMBRE_USUARIO FROM inserted)
	END
go

