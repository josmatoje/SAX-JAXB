--Este trigger se encarga de pagar las apuestas cuando se hace un update a apuestas. Este update solo lo puede llevar a cabo el trigger CERRAR_APUESTAS (Detallado anteriormente)
--Hace uso de las funciones de RESULTADO_APUESTA
CREATE TRIGGER RESOLVER_APUESTA
ON APUESTAS
AFTER UPDATE
AS
	BEGIN
		UPDATE USUARIOS
			SET SALDO = SALDO + (
			SELECT COALESCE(SUM(INS.CANTIDAD * INS.CUOTA),0)
			FROM inserted AS INS
				INNER JOIN deleted AS DEL ON INS.ID = DEL.ID
			WHERE INS.NOMBRE_USUARIO = USUARIOS.NOMBRE
				AND dbo.RESULTADO_APUESTA(INS.ID) = 1
				AND INS.SE_HA_RESUELTO = 1
				AND DEL.SE_HA_RESUELTO = 0
			)
	END
go

