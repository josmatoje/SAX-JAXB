--Estos tres próximos triggers se encargan de preservar la exclusividad de la generalización de APUESTA con sus subentidades.
CREATE TRIGGER ASEGURAR_GENERALIZACION_CORRECTA_GANADOR
	ON APUESTAS_POR_GANADOR
	AFTER INSERT
	AS BEGIN
		IF(EXISTS(
		SELECT * FROM ApuestaTipo
		INNER JOIN inserted ON ApuestaTipo.ID = inserted.ID_APUESTA
		GROUP BY ID
		HAVING COUNT(*) > 1))
			THROW 51001, 'Una apuesta solo puede ser de un solo tipo', 1
	END
go

