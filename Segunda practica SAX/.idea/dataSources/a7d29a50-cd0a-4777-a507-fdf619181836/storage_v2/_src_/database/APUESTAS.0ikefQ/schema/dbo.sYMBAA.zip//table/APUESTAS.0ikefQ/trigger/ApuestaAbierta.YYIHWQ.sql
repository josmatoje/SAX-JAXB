
--El trigger evalua si las entradas en inserted se corresponden con combates y que esos combates tengan el atributo Admite_Apuestas en 1
--En caso contrario lanza una excepcion 
CREATE TRIGGER ApuestaAbierta ON APUESTAS 
	AFTER INSERT AS 
    BEGIN
        IF EXISTS (
            SELECT *
            FROM inserted
                INNER JOIN COMBATES
                    ON inserted.ID_COMBATE = COMBATES.ID
            WHERE COMBATES.ADMITE_APUESTAS = 0
        )
            BEGIN
                THROW 510053, 'No se puede apostar sobre un combate que ya no admite apuestas', 1
            END
    END
go

