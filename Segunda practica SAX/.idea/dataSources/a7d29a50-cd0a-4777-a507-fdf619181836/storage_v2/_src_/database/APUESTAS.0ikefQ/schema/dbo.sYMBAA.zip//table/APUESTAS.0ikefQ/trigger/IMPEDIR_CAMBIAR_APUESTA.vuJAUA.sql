--Este trigger impide la modificación o borrado en la tabla APUESTAS
CREATE TRIGGER IMPEDIR_CAMBIAR_APUESTA
	ON APUESTAS
	AFTER UPDATE, DELETE
	AS BEGIN
		THROW 51001, 'No se puede modificar ni eliminar una apuesta una vez formalizada', 1
	END
go

