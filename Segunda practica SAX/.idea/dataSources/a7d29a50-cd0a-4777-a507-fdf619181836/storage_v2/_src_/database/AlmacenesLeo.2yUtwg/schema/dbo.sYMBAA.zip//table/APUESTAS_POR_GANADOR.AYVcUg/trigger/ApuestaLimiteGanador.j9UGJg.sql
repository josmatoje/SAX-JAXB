CREATE TRIGGER ApuestaLimiteGanador ON APUESTAS_POR_GANADOR
	AFTER INSERT AS
    BEGIN
            ALTER TABLE APUESTAS DISABLE TRIGGER IMPEDIR_CAMBIAR_APUESTA
            --cursor sobre inserted
            DECLARE cursorApuestas CURSOR FOR (
            SELECT ID_APUESTA,NOMBRE_GANADOR, APUESTAS.ID_COMBATE FROM inserted
            INNER JOIN APUESTAS ON APUESTAS.ID = inserted.ID_APUESTA
            )
            OPEN cursorApuestas

            DECLARE @identificador smallint
            DECLARE @nombreGanador varchar(50)
            DECLARE @idCombate  smallint
            DECLARE @excepcion bit = 0

            FETCH NEXT FROM cursorApuestas
            INTO @identificador, @nombreGanador, @idCombate

            WHILE @@FETCH_STATUS = 0
            BEGIN
                IF (EXISTS(SELECT SUM(AP.CANTIDAD * AP.CUOTA)
                FROM APUESTAS AS AP
                INNER JOIN COMBATES AS CO
                    ON CO.ID = AP.ID_COMBATE
                INNER JOIN APUESTAS_POR_GANADOR AS AP_G
                    ON AP.ID = AP_G.ID_APUESTA
                WHERE
                    AP_G.NOMBRE_GANADOR = @nombreGanador AND AP.ID_COMBATE = @idCombate
                GROUP BY
                    AP.ID_COMBATE, CO.MAX_APUESTAS_POR_GANADOR, AP_G.NOMBRE_GANADOR
                HAVING

                    SUM(AP.CANTIDAD * AP.CUOTA) > CO.MAX_APUESTAS_POR_GANADOR

                ))
                    BEGIN
                        DELETE FROM APUESTAS WHERE APUESTAS.ID = @identificador
                        SET @excepcion = 1
                    END
                FETCH NEXT FROM cursorApuestas
                INTO @identificador, @nombreGanador, @idCombate
            END

            CLOSE cursorApuestas;
            DEALLOCATE cursorApuestas;

            ALTER TABLE APUESTAS ENABLE TRIGGER IMPEDIR_CAMBIAR_APUESTA

    END
go

