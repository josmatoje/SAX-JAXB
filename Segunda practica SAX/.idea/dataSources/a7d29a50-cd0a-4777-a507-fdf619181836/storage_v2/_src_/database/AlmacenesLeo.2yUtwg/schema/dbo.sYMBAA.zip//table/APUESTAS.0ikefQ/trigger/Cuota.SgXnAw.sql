
--Este trigger genera una cuota de apuesta aleatoria
--A riesgo de contradecir los requisitos, hemos decidido realizar la asignación de la cuota mediante este trigger en lugar de con un función escalar
--El razonamiento es que el modelo actual no abarca muchos factores que podrían ser de peso a la hora de calcular la dificultad de una apuesta
--Por tanto, hemos preferido que este juicio se realice sujbetiva y manualmente en el momento en que se vaya a realizar la inserción, otorgando
--un valor inicial a la cuota y permitiendo que este se vea modificado en una medida aleatoria por el trigger
CREATE TRIGGER Cuota
ON APUESTAS AFTER INSERT
AS BEGIN
	ALTER TABLE APUESTAS DISABLE TRIGGER IMPEDIR_CAMBIAR_APUESTA

	UPDATE APUESTAS
	SET CUOTA = CUOTA * (RAND() * 2 + 1) FROM APUESTAS
	WHERE APUESTAS.ID IN (SELECT ID FROM inserted)

	ALTER TABLE APUESTAS ENABLE TRIGGER IMPEDIR_CAMBIAR_APUESTA
END
go

