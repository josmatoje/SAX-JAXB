
--Cuando se modifica el saldo de un usuario, este trigger emite una transacción con la información pertinente en la tabla TRANSACCIONES.
CREATE TRIGGER CREAR_TRANSACCION
	ON USUARIOS
	AFTER UPDATE
	AS
	BEGIN
		INSERT INTO TRANSACCIONES (NOMBRE_USUARIO, IMPORTE)
		SELECT inserted.NOMBRE, inserted.SALDO - deleted.SALDO
			FROM inserted JOIN deleted ON inserted.NOMBRE = deleted.NOMBRE
			WHERE inserted.SALDO != deleted.SALDO
	END
go

