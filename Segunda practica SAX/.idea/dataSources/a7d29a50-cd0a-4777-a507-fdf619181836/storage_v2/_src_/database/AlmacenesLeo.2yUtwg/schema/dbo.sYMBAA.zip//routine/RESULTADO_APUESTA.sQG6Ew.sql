
--Esta función se encarga de calcular si una apuesta específica  es ganadora. 
--Para ello llama a otras funciones (Detalladas a continuación de esta) específicas a cada tipo de apuesta.
CREATE FUNCTION RESULTADO_APUESTA (@ID_APUESTA SMALLINT)
	RETURNS INT
AS
	BEGIN
		DECLARE @HA_GANADO BIT
		DECLARE @TIPO VARCHAR(200)

		SELECT @TIPO = TIPO
			FROM ApuestaTipo
			WHERE ID = @ID_APUESTA

		IF(@TIPO = 'Ganador')
			SET @HA_GANADO = DBO.RESULTADO_APUESTA_POR_GANADOR(@ID_APUESTA)
		ELSE IF (@TIPO = 'Puntuacion')
			SET @HA_GANADO = DBO.RESULTADO_APUESTA_POR_PUNTUACION(@ID_APUESTA)
		ELSE
			SET @HA_GANADO = DBO.RESULTADO_APUESTA_POR_TIPO_DE_VICTORIA(@ID_APUESTA)

		RETURN @HA_GANADO
	END
go

